import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { OBJLoader } from 'three/addons/loaders/OBJLoader.js';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';

const UIElements = {
    spinner: document.getElementById('spinner'),
    generateBtn: document.getElementById('generateBtn'),
    voxelizeBtn: document.getElementById('voxelizeBtn'),
    mapBtn: document.getElementById('mapBtn'),
    downloadSchemBtn: document.getElementById('downloadSchemBtn'),
    downloadLiteBtn: document.getElementById('downloadLiteBtn'),
    viewSolidBtn: document.getElementById('viewSolidBtn'),
    viewTextureBtn: document.getElementById('viewTextureBtn'),
    imageInput: document.getElementById('imageInput'),
    imagePreview: document.getElementById('imagePreview'),
    uploadBox: document.getElementById('uploadBox'),
    resolutionSlider: document.getElementById('resolution'),
    resolutionValue: document.getElementById('resolutionValue'),
    maxBlocksSlider: document.getElementById('maxBlocks'),
    maxBlocksValue: document.getElementById('maxBlocksValue'),
    maxHeightInput: document.getElementById('maxHeight'),
    fillInteriorCheckbox: document.getElementById('fillInterior'),
    voxelizeControls: document.getElementById('voxelizeControls'),
    mapControls: document.getElementById('mapControls'),
    exportControls: document.getElementById('exportControls'),
};

let renderer, scene, camera, controls, currentObject;
let lastSessionId = null;
let lastVoxelRgbUrl = null;
let lastBlockGridUrl = null;
let textureLoader, atlasTexture;
let BLOCK_UV_MAP_DATA = {};
const ATLAS_URL = '/assets/vanilla.png';

async function init() {
    initViewer();
    initEventListeners();
    textureLoader = new THREE.TextureLoader();
    await loadBlockUvMap();
}

function initViewer() {
    const container = document.getElementById('viewer');
    renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.setSize(container.clientWidth, container.clientHeight);
    container.appendChild(renderer.domElement);
    scene = new THREE.Scene();
    scene.background = new THREE.Color(0xecf2f9);
    camera = new THREE.PerspectiveCamera(50, container.clientWidth / container.clientHeight, 0.1, 1000);
    camera.position.set(0, 1.5, 3.5);
    controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    const light = new THREE.DirectionalLight(0xffffff, 1.0);
    light.position.set(5, 10, 7.5);
    scene.add(new THREE.AmbientLight(0xffffff, 0.8), light);
    scene.add(new THREE.GridHelper(10, 20, 0xcccccc, 0xcccccc));
    const animate = () => { requestAnimationFrame(animate); controls.update(); renderer.render(scene, camera); };
    animate();
}

function initEventListeners() {
    UIElements.resolutionSlider.oninput = e => UIElements.resolutionValue.textContent = e.target.value;
    UIElements.maxBlocksSlider.oninput = e => UIElements.maxBlocksValue.textContent = e.target.value;
    UIElements.uploadBox.onclick = () => UIElements.imageInput.click();
    UIElements.imageInput.onchange = () => {
        const file = UIElements.imageInput.files[0];
        if (file) {
            UIElements.imagePreview.src = URL.createObjectURL(file);
            UIElements.imagePreview.style.display = 'block';
            UIElements.uploadBox.querySelector('label').style.display = 'none';
            ['voxelizeControls', 'mapControls', 'exportControls'].forEach(id => UIElements[id].style.display = 'none');
        }
    };
    document.getElementById('reconstructForm').onsubmit = handleReconstruct;
    UIElements.voxelizeBtn.onclick = handleVoxelize;
    UIElements.mapBtn.onclick = handleMapBlocks;
    UIElements.downloadSchemBtn.onclick = () => handleExport('schem');
    UIElements.downloadLiteBtn.onclick = () => handleExport('litematic');
    UIElements.viewSolidBtn.onclick = renderSolidColorVoxel;
    UIElements.viewTextureBtn.onclick = renderTextureVoxel;
}

async function performFetch(url, options, button, loadingText, originalText, onSuccess) {
    setLoading(true, button, loadingText);
    try {
        const res = await fetch(url, options);
        if (!res.ok) {
            const errData = await res.json().catch(() => ({ detail: "Respons server tidak valid." }));
            throw new Error(errData.detail || "Terjadi kesalahan tidak diketahui.");
        }
        const data = await res.json();
        if (onSuccess) await onSuccess(data);
    } catch (err) {
        alert(`Error: ${err.message}`);
    } finally {
        setLoading(false, button, originalText);
    }
}

function setLoading(isLoading, button = null, text = '') {
    UIElements.spinner.style.display = isLoading ? 'block' : 'none';
    if (button) {
        button.disabled = isLoading;
        if (text) button.textContent = text;
    }
    // Disable all major action buttons during a process
    [UIElements.generateBtn, UIElements.voxelizeBtn, UIElements.mapBtn].forEach(btn => btn.disabled = isLoading);
}

// === HANDLER UNTUK SETIAP TAHAPAN ===

async function handleReconstruct(e) {
    e.preventDefault();
    if (!UIElements.imageInput.files.length) return alert("Pilih gambar!");
    
    const formData = new FormData();
    formData.append('image', UIElements.imageInput.files[0]);
    formData.append('remove_bg', document.getElementById('removeBg').checked);
    formData.append('resolution', UIElements.resolutionSlider.value);

    await performFetch('/reconstruct', { method: 'POST', body: formData }, UIElements.generateBtn, 'Merekonstruksi...', 'Generate 3D Model', (data) => {
        lastSessionId = data.sessionId;
        loadModel(data.objUrl, data.textureUrl);
        UIElements.voxelizeControls.style.display = 'block';
        ['mapControls', 'exportControls'].forEach(id => UIElements[id].style.display = 'none');
    });
}

async function handleVoxelize() {
    if (!lastSessionId) return alert("Generate model dulu!");
    const payload = {
        sessionId: lastSessionId,
        max_blocks: parseInt(UIElements.maxBlocksSlider.value),
        fill: UIElements.fillInteriorCheckbox.checked,
        max_height: parseInt(UIElements.maxHeightInput.value) || 0
    };
    await performFetch('/voxelize', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }, UIElements.voxelizeBtn, 'Memproses...', 'Voxelize ke Warna', async (data) => {
        lastVoxelRgbUrl = data.voxelRgbUrl;
        await renderSolidColorVoxel();
        UIElements.mapControls.style.display = 'block';
        UIElements.exportControls.style.display = 'none';
        setActivePreview(UIElements.viewSolidBtn);
    });
}

async function handleMapBlocks() {
    if (!lastSessionId) return alert("Voxelize dulu!");
    const payload = { sessionId: lastSessionId };
    await performFetch('/map-blocks', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }, UIElements.mapBtn, 'Assigning...', 'Assign Minecraft Blocks', (data) => {
        lastBlockGridUrl = data.blockGridUrl;
        UIElements.exportControls.style.display = 'block';
        renderTextureVoxel(); // Otomatis tampilkan preview tekstur setelah selesai
        setActivePreview(UIElements.viewTextureBtn);
    });
}

async function handleExport(format) {
    if (!lastSessionId) return alert("Lakukan semua tahap sebelumnya!");
    const btn = format === 'schem' ? UIElements.downloadSchemBtn : UIElements.downloadLiteBtn;
    const originalText = btn.textContent;
    
    const formData = new FormData();
    formData.append('sessionId', lastSessionId);
    formData.append('format', format);

    await performFetch('/export', { method: 'POST', body: formData }, btn, 'Mengekspor...', originalText, (data) => {
        const link = document.createElement('a');
        link.href = data.fileUrl;
        link.download = `model_${lastSessionId.substring(0,8)}.${format}`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    });
}

// === FUNGSI RENDER DAN BANTUAN LAINNYA ===

function clearScene() {
    if (currentObject) {
        scene.remove(currentObject);
        currentObject.traverse(c => {
            if (c.isMesh) {
                c.geometry.dispose();
                if (Array.isArray(c.material)) c.material.forEach(m => { m.map?.dispose(); m.dispose(); });
                else if (c.material) { c.material.map?.dispose(); c.material.dispose(); }
            }
        });
    }
    currentObject = null;
}

function loadModel(objUrl, textureUrl) {
    clearScene();
    const onModelLoad = (obj) => {
        const box = new THREE.Box3().setFromObject(obj);
        const size = box.getSize(new THREE.Vector3());
        const scale = 2.0 / Math.max(size.x, size.y, size.z);
        obj.scale.set(scale, scale, scale);
        obj.position.sub(box.getCenter(new THREE.Vector3()).multiplyScalar(scale));
        scene.add(obj);
        currentObject = obj;
    };
    textureLoader.load(textureUrl, (texture) => {
        texture.colorSpace = THREE.SRGBColorSpace;
        new OBJLoader().load(objUrl, obj => {
            obj.traverse(c => { if (c.isMesh) c.material = new THREE.MeshStandardMaterial({ map: texture }); });
            onModelLoad(obj);
        });
    }, undefined, () => new OBJLoader().load(objUrl, onModelLoad));
}

async function renderSolidColorVoxel() {
    if (!lastVoxelRgbUrl) return alert("Jalankan Voxelize dulu!");
    setLoading(true);
    try {
        const grid = await (await fetch(lastVoxelRgbUrl)).json();
        clearScene();
        if (!grid || grid.length === 0) return;
        
        const [nx, ny, nz] = [grid.length, grid[0].length, grid[0][0].length];
        const boxSize = 2.0 / Math.max(nx, ny, nz);
        const materialMap = new Map();

        for (let x = 0; x < nx; x++) for (let y = 0; y < ny; y++) for (let z = 0; z < nz; z++) {
            const c = grid[x][y][z];
            if (c[0] === 0 && c[1] === 0 && c[2] === 0) continue;
            const colorHex = (c[0] << 16) | (c[1] << 8) | c[2];
            const geo = new THREE.BoxGeometry(boxSize, boxSize, boxSize);
            geo.translate((x - nx/2 + 0.5)*boxSize, (y - ny/2 + 0.5)*boxSize, (z - nz/2 + 0.5)*boxSize);
            if (!materialMap.has(colorHex)) materialMap.set(colorHex, []);
            materialMap.get(colorHex).push(geo);
        }

        const group = new THREE.Group();
        for (const [color, geometries] of materialMap.entries()) {
            if (geometries.length > 0) {
                group.add(new THREE.Mesh(mergeGeometries(geometries), new THREE.MeshStandardMaterial({ color })));
            }
        }
        scene.add(group);
        currentObject = group;
        setActivePreview(UIElements.viewSolidBtn);
    } finally {
        setLoading(false);
    }
}

async function renderTextureVoxel() {
    if (!lastBlockGridUrl) return alert("Jalankan Assign Blocks dulu!");
    setLoading(true);
    try {
        if (!atlasTexture) {
            atlasTexture = await textureLoader.loadAsync(ATLAS_URL);
            atlasTexture.magFilter = THREE.NearestFilter;
            atlasTexture.minFilter = THREE.NearestFilter;
        }
        const blockGrid = await (await fetch(lastBlockGridUrl)).json();
        clearScene();
        if (!blockGrid || blockGrid.length === 0) return;

        const [nx, ny, nz] = [blockGrid.length, blockGrid[0].length, blockGrid[0][0].length];
        const boxSize = 2.0 / Math.max(nx, ny, nz);
        const geometriesByBlock = new Map();
        
        for (let x = 0; x < nx; x++) for (let y = 0; y < ny; y++) for (let z = 0; z < nz; z++) {
            const blockName = blockGrid[x][y][z].replace('minecraft:', '');
            if (blockName === 'air') continue;
            const geo = new THREE.BoxGeometry(boxSize, boxSize, boxSize);
            geo.translate((x - nx/2 + 0.5)*boxSize, (y - ny/2 + 0.5)*boxSize, (z - nz/2 + 0.5)*boxSize);
            if (!geometriesByBlock.has(blockName)) geometriesByBlock.set(blockName, []);
            geometriesByBlock.get(blockName).push(geo);
        }

        const finalGroup = new THREE.Group();
        const mainMaterial = new THREE.MeshStandardMaterial({ map: atlasTexture });

        for (const [blockName, geometries] of geometriesByBlock.entries()) {
            if (geometries.length > 0) {
                const mergedGeo = mergeGeometries(geometries);
                const uvData = BLOCK_UV_MAP_DATA[blockName] || BLOCK_UV_MAP_DATA['fallback'] || [0,0,0.05,0.05];
                const [u0, v0, u1, v1] = uvData;
                const uvs = mergedGeo.attributes.uv.array;
                for (let i = 0; i < uvs.length; i += 2) {
                    uvs[i] = u0 + uvs[i] * (u1 - u0);
                    uvs[i+1] = 1 - (v0 + uvs[i+1] * (v1 - v0));
                }
                finalGroup.add(new THREE.Mesh(mergedGeo, mainMaterial));
            }
        }
        scene.add(finalGroup);
        currentObject = finalGroup;
        setActivePreview(UIElements.viewTextureBtn);
    } finally {
        setLoading(false);
    }
}

async function loadBlockUvMap() {
    try {
        const response = await fetch('/assets/block_uv_map.json');
        if (!response.ok) throw new Error('Gagal memuat block_uv_map.json');
        BLOCK_UV_MAP_DATA = await response.json();
        console.log("Block UV Map berhasil dimuat.");
    } catch (error) {
        console.error(error);
        alert("Gagal memuat aset penting. Pratinjau tekstur mungkin tidak berfungsi.");
    }
}

function setActivePreview(activeButton) {
    [UIElements.viewSolidBtn, UIElements.viewTextureBtn].forEach(btn => btn.classList.remove('active'));
    if (activeButton) {
        activeButton.classList.add('active');
    }
}

window.onresize = () => {
    if (!renderer || !camera) return;
    const container = document.getElementById('viewer');
    camera.aspect = container.clientWidth / container.clientHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(container.clientWidth, container.clientHeight);
};

init();