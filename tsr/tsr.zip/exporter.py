import math
import logging
import numpy as np
import nbtlib
from nbtlib.tag import *

from block_mapper import BlockMesh

# =========================================================================================
# FUNGSI-FUNGSI BANTUAN UNTUK SERIALISASI NBT
# =========================================================================================

def calculate_bits_per_block(palette_size):
    """
    Menghitung jumlah bit yang dibutuhkan per blok dalam packed array.
    Minimum adalah 4 bit.
    """
    if palette_size <= 1:
        return 4
    return max(4, math.ceil(math.log2(palette_size)))

def pack_block_states(palette_ids, bits_per_block):
    """
    Mengepak array ID palet menjadi LongArray sesuai format Litematic/Schematic modern.
    """
    packed = []
    current_long = 0
    bits_filled = 0
    
    # Nilai batas untuk signed 64-bit integer
    SIGNED_64_BIT_MAX = 2**63
    UNSIGNED_64_BIT_MAX = 2**64

    for pid in palette_ids:
        palette_id = int(pid)
        
        current_long |= (palette_id << bits_filled)
        bits_filled += bits_per_block

        while bits_filled >= 64:
            # Ambil 64 bit terendah dari current_long
            long_to_pack = current_long & (UNSIGNED_64_BIT_MAX - 1)
            
            # --- PERBAIKAN INTI: Konversi Two's Complement ---
            # Jika bit ke-63 adalah 1, angka ini harus direpresentasikan sebagai negatif
            # agar sesuai dengan tipe data signed Long NBT.
            if long_to_pack >= SIGNED_64_BIT_MAX:
                long_to_pack -= UNSIGNED_64_BIT_MAX
            # --- AKHIR PERBAIKAN ---

            packed.append(long_to_pack)
            
            current_long >>= 64
            bits_filled -= 64

    if bits_filled > 0:
        # Tidak perlu konversi untuk sisa, karena tidak akan pernah mencapai 64 bit
        packed.append(current_long)

    return packed

# =========================================================================================
# KELAS EXPORTER UTAMA
# =========================================================================================

class Exporter:
    def __init__(self, block_mesh: BlockMesh):
        self.block_mesh = block_mesh
        min_b, max_b = self.block_mesh.get_bounds()

        self.width = max(1, int(max_b.x - min_b.x + 1))  # Sumbu X
        self.height = max(1, int(max_b.y - min_b.y + 1)) # Sumbu Y
        self.length = max(1, int(max_b.z - min_b.z + 1)) # Sumbu Z
        self.min_bounds = min_b

        self._build_palette()

    def _build_palette(self):
        """Membangun palet blok unik dan memetakannya ke integer."""
        self.unique_blocks = self.block_mesh.get_block_palette()
        self.palette_map = {name: i for i, name in enumerate(self.unique_blocks)}
        
        if "minecraft:air" not in self.palette_map:
            air_id = len(self.unique_blocks)
            self.unique_blocks.append("minecraft:air")
            self.palette_map["minecraft:air"] = air_id

    def export_to_schem(self, filename: str):
        """Mengekspor ke format .schem (digunakan oleh WorldEdit)."""
        logging.info(f"Mengekspor ke format .schem modern: {filename}")

        nbt_palette = Compound({name: Int(i) for name, i in self.palette_map.items()})
        
        # Urutan sumbu untuk .schem adalah Y, Z, X
        block_ids = np.full((self.height, self.length, self.width), self.palette_map["minecraft:air"], dtype=np.int32)

        for block in self.block_mesh.get_blocks():
            x = int(block.position.x - self.min_bounds.x)
            y = int(block.position.y - self.min_bounds.y)
            z = int(block.position.z - self.min_bounds.z)
            if 0 <= x < self.width and 0 <= y < self.height and 0 <= z < self.length:
                block_ids[y, z, x] = self.palette_map[block.name]

        flat_ids = block_ids.flatten()
        bits_per_block = calculate_bits_per_block(len(self.palette_map))
        packed_block_data = pack_block_states(flat_ids, bits_per_block)

        schem_nbt = nbtlib.File({
            'Version': Int(3),
            'DataVersion': Int(3953),
            'Width': Short(self.width),
            'Height': Short(self.height),
            'Length': Short(self.length),
            'Palette': nbt_palette,
            'BlockData': LongArray(packed_block_data),
            'Metadata': Compound({
                'WEOffsetX': Int(0),
                'WEOffsetY': Int(0),
                'WEOffsetZ': Int(0)
            })
        }, gzipped=True)

        schem_nbt.save(filename)
        logging.info("Ekspor .schem selesai.")

    def export_to_litematic(self, filename: str):
        """Mengekspor ke format .litematic (digunakan oleh Litematica mod)."""
        logging.info(f"Mengekspor ke format .litematic: {filename}")

        region_name = "ReconstructedModel"
        total_volume = self.width * self.height * self.length

        # Urutan sumbu untuk .litematic adalah Y, Z, X
        block_ids = np.full((self.height, self.length, self.width), self.palette_map["minecraft:air"], dtype=np.int32)

        for block in self.block_mesh.get_blocks():
            x = int(block.position.x - self.min_bounds.x)
            y = int(block.position.y - self.min_bounds.y)
            z = int(block.position.z - self.min_bounds.z)
            if 0 <= x < self.width and 0 <= y < self.height and 0 <= z < self.length:
                block_ids[y, z, x] = self.palette_map[block.name]
        
        flat_ids = block_ids.flatten()
        bits_per_block = calculate_bits_per_block(len(self.palette_map))
        packed_block_states = pack_block_states(flat_ids, bits_per_block)

        litematic_palette = List[Compound]([
            Compound({'Name': String(name)}) for name in self.unique_blocks
        ])

        region = Compound({
            'Position': Compound({'x': Int(0), 'y': Int(0), 'z': Int(0)}),
            'Size': Compound({'x': Int(self.width), 'y': Int(self.height), 'z': Int(self.length)}),
            'Palette': litematic_palette,
            'BlockStates': LongArray(packed_block_states)
        })

        litematic_nbt = nbtlib.File({
            'MinecraftDataVersion': Int(3953),
            'Version': Int(6),
            'Metadata': Compound({
                'Author': String("Squareclouds"),
                'Name': String(region_name),
                'RegionCount': Int(1),
                'TimeCreated': Long(0),
                'TimeModified': Long(0),
                'TotalBlocks': Int(len(self.block_mesh.get_blocks())),
                'TotalVolume': Int(total_volume)
            }),
            'Regions': Compound({
                region_name: region
            })
        }, gzipped=True)

        schem_nbt.save(filename)
        logging.info("Ekspor .litematic selesai.")
